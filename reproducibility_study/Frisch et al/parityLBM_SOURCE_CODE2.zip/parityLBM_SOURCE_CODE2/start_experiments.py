from lbm_ordinal import LbmOrdinal
import pickle
import time
import torch
import numpy as np
import time
import warnings
import argparse
import glob
import os
import errno
from sklearn import metrics
from sklearn.metrics import ndcg_score


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ("yes", "true", "t", "y", "1"):
        return True
    elif v.lower() in ("no", "false", "f", "n", "0"):
        return False
    else:
        raise argparse.ArgumentTypeError("Boolean value expected.")


parser = argparse.ArgumentParser()
parser.add_argument("--gpu", default=0, type=int)
parser.add_argument("--block", default=0, type=int)
parser.add_argument("--nq", default=15, type=int)
parser.add_argument("--nl", default=15, type=int)

args = parser.parse_args()
if torch.cuda.is_available():
    device = torch.device("cuda:" + str(args.gpu))
else:
    device = torch.device("cpu")
warnings.filterwarnings("ignore")

data = pickle.load(open("./data/ml-1m_five_blocks_topk.pkl", "rb"))
block = args.block

X_train = np.array(data["blocks"][block]["X_train"].todense())
X_test = np.array(data["blocks"][block]["X_test"].todense())

X = X_train
n1, n2 = X.shape
nq, nl = args.nq, args.nl
nk = 5


females = (
    data["data_users"].userid[data["data_users"].gender == "F"].to_numpy()
)
males = data["data_users"].userid[data["data_users"].gender == "M"].to_numpy()
groups = (females, males)

covariates = np.array(np.zeros_like(X_train))
covariates[males] = 1
covariates[females] = -1
covariates = covariates.reshape(X_train.shape[0], X_train.shape[1], 1)
covariates = covariates.astype(float)

test_data = np.array(
    [X_test[i, X_test[i,].nonzero()].flatten().tolist() for i in range(n1)]
)


directory = "results/"

if not os.path.exists(directory):
    try:
        os.makedirs(directory)
    except OSError as error:
        if error.errno != errno.EEXIST:
            raise

to_save = []
for _ in range(25):
    try:
        model = LbmOrdinal(device=device)

        def callback(model, epoch=0):
            chi2 = torch.stack([model.tau_1[gr].sum(0) for gr in groups])
            chi2_stat = (
                (
                    chi2
                    - (
                        chi2.sum(0).reshape(1, nq)
                        * chi2.sum(1).reshape(len(groups), 1)
                    )
                    / chi2.sum()
                )
                ** 2
                / (
                    (
                        chi2.sum(0).reshape(1, nq)
                        * chi2.sum(1).reshape(len(groups), 1)
                    )
                    / chi2.sum()
                )
            ).sum()

            pred_cov = (
                (
                    model.tau_1 @ model.pi @ model.tau_2.T
                    + model.eta_row
                    + model.eta_col
                    + 1
                )
                .detach()
                .cpu()
                .numpy()
            )
            pred_test_cov = np.array(
                [
                    pred_cov[i, X_test[i,].nonzero()].flatten().tolist()
                    for i in range(n1)
                ]
            )

            ndcg_10_cov = ndcg_score(test_data, pred_test_cov, k=10)
            ndcg_10_cov_females = ndcg_score(
                test_data[groups[0]], pred_test_cov[groups[0]], k=10
            )
            ndcg_10_cov_males = ndcg_score(
                test_data[groups[1]], pred_test_cov[groups[1]], k=10
            )
            print(
                f"NDCG@10 all : {ndcg_10_cov:.5f} \t Females {ndcg_10_cov_females:.5f} \t Males {ndcg_10_cov_males:.5f} \t Chi_stat : {chi2_stat.item():.1f}"
            )

        model.fit(
            X,
            nq,
            nl,
            lr=2e-2,
            cov=covariates,
            max_epoch=300,
            batch_size=(200, 200),
            scheduler_options={
                "mode": "min",
                "factor": 0.2,
                "patience": 20,
                "cooldown": 20,
            },
            callback=callback,
        )
        res = {"block": block, "nq": nq, "nl": nl, "model": model.to_numpy()}

        res.update(
            {
                "nll": model.get_ll(X, nq, nl, cov=covariates)
                .detach()
                .cpu()
                .item()
            }
        )
        to_save.append(res)

    except Exception as e:
        print(e)


pickle.dump(to_save, open(directory + "block_" + str(block) + ".pkl", "wb"))
